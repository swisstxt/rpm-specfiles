PhusionPassenger.install_framework_extensions! if defined?(PhusionPassenger)
