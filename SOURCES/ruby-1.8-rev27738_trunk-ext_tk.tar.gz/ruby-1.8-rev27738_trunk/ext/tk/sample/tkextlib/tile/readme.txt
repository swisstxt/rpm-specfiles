All of *.tcl and under themes/ directory (except kroc.rb) are 
quoted from Tcl/Tk's Tile extension. Please read Orig_LICENSE.txt. 
