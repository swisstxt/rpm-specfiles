
  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
  >>>  The following text is the original 'README.txt' of  <<<
  >>>  vu extension demos.                                 <<<
  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

##
## DESCRIPTION OF DEMOS
##

canvItems.tcl
	old demo of all canvas chart items, useful to find memory leaks.
	<1> prints out the additional memory usage (charts.so + script)

canvSticker.tcl
	Heribert Dahms original "demo.tcl"
	<p> creates DEMO.ps

canvSticker2.tcl
	compares "sticker" and "text"; press <1>, <2> or <1> ...
	<p> creates DEMO.ps

dial.tcl
	demo of variations of the dial widget.

load.tcl
	Just a utility file, not a real demo.

m128_000.xbm
	XBM pic used by sticker and canvItems demos

oscilloscope.tcl
	the heart of a Realtime Oscilloscope,where the PC�s joystick
	port gives 4 digtal inputs and 4 analog 8 bit values with an
	resolution of ~1 millisecond (!!!)  running Realtime Linux.
	<p> creates DEMO.ps

pie.tcl
	The magic 3D spinning pie chart!

vu.tcl
	demo fo Vu widgets

canvLabel.tcl
	'label' is a canvas item just like 'text', but with -angle
	rotation of the string.  This is not built in by default, as
	it requires the internal Tk headers.
	press <1>, <2> or <1> ...
	<p> creates DEMO.ps

